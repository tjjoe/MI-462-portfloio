Database Project Phase 2
Christopher LaRosa, TJ Augustine, Chris O'Callaghan

Run the files in this order:

Tables are created in "Phase 2 CREATE.sql"
Triggers are created in "Phase 2 TRIGGERS.sql"
Dummy data is inserted in "Phase 2 INSERT.sql" (Make sure to compile triggers before insert)

Reports are in their respective files, each containing a procedure which generates the report